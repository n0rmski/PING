This is good for checking out potential new alleles or for making consensus sequence from homozygous.
- Pick the closest match by gene/allele content from the spreadsheet called DanHaps.xlsx
- Download the fas (fna) and gbk versions of haplotype from GenBank
- put everything in the right folders ;-/
- load the resulting .bam in IGV, or .g5x file in Staden Gap5 [I use both] or another aread/alignment viewer
- don't ask me anything about Staden or IGV
- validate your new SNP or recombinant

tips: BLAST is good for double checking the read comes from locus in question
nBLAST is becomimg noisy so I set up a local BLAST with the sequences in the 'noMonkeys' fasta file included

There is one working copy included -the RSH KIR B haplotype - you should see the annotations in IGV
-and one set of reads in the Seqs folder

Please confirm sequence using another method before submitting to GenBank..
